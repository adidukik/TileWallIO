package x;

public abstract class XApp {
    public abstract XScenarioMgr getScenarioMgr();
    public abstract XLogMgr getLogMgr();
}
