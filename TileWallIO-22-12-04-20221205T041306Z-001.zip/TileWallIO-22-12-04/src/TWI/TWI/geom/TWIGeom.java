package TWI.geom;

import TWI.TWIRenderable;

public abstract class TWIGeom implements TWIRenderable {
}
