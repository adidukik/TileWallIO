package TWI.geom;

public class TWICurve extends TWIGeom {
    @Override
    public void render() {
        // TODO Auto-generated method stub
    }

    @Override
    public void refresh() {
        // TODO Auto-generated method stub
    }

}
