package TWI.manager;

import TWI.TWI;

public class TWIPreviewMgr {
    // fields
    private TWI mTWI = null;

    public TWIPreviewMgr(TWI twi) {
        this.mTWI = twi;
    }

    // methods
    public void update() {
        // TODO
    }
}
