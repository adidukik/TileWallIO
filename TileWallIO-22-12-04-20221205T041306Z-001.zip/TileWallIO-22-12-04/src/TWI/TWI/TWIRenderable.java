package TWI;

public interface TWIRenderable {
    public abstract void render();
    public abstract void refresh();
}
